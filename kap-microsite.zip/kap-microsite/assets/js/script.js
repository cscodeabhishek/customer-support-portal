function toggleFaq(faqId) {
    var faqItem = document.getElementById(faqId);
    var faqContent = faqItem.querySelector(".accordion-content");

    // Close all other FAQ items
    var allFaqItems = document.querySelectorAll(".accordion-item");
    allFaqItems.forEach(function (item) {
        if (item.id !== faqId) {
            item.setAttribute("aria-expanded", "false");
            item.classList.remove("open-faq");
            item.querySelector(".accordion-content").style.maxHeight = "0";
        }
    });
    // Toggle the clicked FAQ item
    var isExpanded = faqItem.getAttribute("aria-expanded") === "true";
    faqItem.setAttribute("aria-expanded", isExpanded ? "false" : "true");
    faqItem.classList.toggle("open-faq", !isExpanded);

    // Handle the transition
    faqContent.style.maxHeight = isExpanded ? "0" : faqContent.scrollHeight + "px";
}

document.addEventListener("DOMContentLoaded", function () {
    var checkboxes = document.querySelectorAll('.accordion-item input[type="checkbox"]');
    checkboxes.forEach(function (checkbox) {
        checkbox.addEventListener("change", function () {
            checkboxes.forEach(function (otherCheckbox) {
                if (otherCheckbox !== checkbox) {
                    otherCheckbox.checked = false;
                }
            });
        });
    });
});
