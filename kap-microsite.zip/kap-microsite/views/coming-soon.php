<?php include "../includes/header.php"; ?>
<div class="coming-soon-section">
    <h2>Coming soon!!!</h2>
</div>
<?php include "../includes/footer.php"; ?>