<?php include "../includes/header.php"; ?>
<div class="bc-parent-cat">
    <div class="bc-child-cat">
     <a href="<?php echo BASE_URL ?>">Home ></a>
     <span> insurance</span>
    </div>
</div>
<div class="accordion">
    <div class="accordion-item">
        <input type="checkbox" id="accordion1" checked />
        <label for="accordion1" class="accordion-item-title"><span class="icon"></span>Login Credentials (Admin)</label>
        <div class="accordion-item-desc">
            <p class="para-description">Use the following login credentials (URL, username and password) to access the demo account. Explore the features and functionalities available to get a feel for the full experience.</p>
            <div class="parent-div">
                <div class="child-div-three">
                    <a href="https://demoinsurance.kapturecrm.com/nui/login" target="_blank"><span>URL:</span> &nbsp;demo.kapturecrm.com/nui/</a>
                </div>
                <div class="child-div-three"><span>Username:</span> &nbsp; Admin</div>
                <div class="child-div-three"><span>Password: </span> &nbsp;Admin@123</div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion2" />
        <label for="accordion2" class="accordion-item-title"><span class="icon"></span>Login Credentials (Other Employees)</label>
        <div class="accordion-item-desc">
            <p class="para-description">Use the following login credentials (URL, username and password) to access the demo account. Explore the features and functionalities available to get a feel for the full experience.</p>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Claims,Issue,Payment,Legality,Feedback,Call,Email,Online Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ANKITA JHA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; jha.ankita@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Issue,Legality</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ANAGHA S</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; s.anagha@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Issue,Feedback,Email,Online Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ANIKET KUMAR</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; kumar.aniket@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; 3b85091</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Claims,Issue,Legality,Online Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; ANKITA JHA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; jha.ankita@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; fablc2b</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Claims,Payment,Legality,Feedback,Online Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; FAITH</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; faith.123@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Payment,Feedback</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; GAURAV GUPTA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; gauri.gupta@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; GAURI GUPTA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; gauri.gupta@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Feedback</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; NANCY RANI</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; rani.nancy@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Issue,Payment,Legality,Feedback</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; PANKAJ UDAAS</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; udaas.pankaj@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Claims,Legality,Email</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; PREETI SHARMA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; preeti.sharma@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Claims,Issue,Legality,Email</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; PURVI SINGH</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; singh.purvi@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Enquiry,Payment,Feedback,Email,Online Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; SHIVIKA SINHA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; sinha.shivika@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Payment,Issue,Online Chat</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; SHREYA ROY</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; roy.shreya@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Payment,Email</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; SIYA</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; siya.siya@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; K@abc123</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-four">
                    <p><span>Queue:</span> &nbsp; Claims</p>
                </div>
                <div class="child-div-four">
                    <p><span>Name:</span> &nbsp; Abhishek Thakur</p>
                </div>
                <div class="child-div-four">
                    <p><span>Username:</span> &nbsp; Thakur123@gmail.com</p>
                </div>
                <div class="child-div-four">
                    <p><span>Password:</span> &nbsp; Thakur@abc123</p>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion3" />
        <label for="accordion3" class="accordion-item-title"><span class="icon"></span>Self-Serve</label>
        <div class="accordion-item-desc">
            <h2 class="heading">Insure Wise</h2>
            <p class="para-description">
                This website offers a comprehensive customer service experience. Access all FAQs, raise queries, and track the status of your requests effortlessly. View and manage all your orders conveniently in one place. Our AI chatbot
                is available to assist you with any issues regarding your orders or the platform. Additionally, streamline your communication with us using pre-defined messages through Kapture CX for quick and efficient interactions.
            </p>
            <p class="note">Note:</p>
            Login to your own account by entering your email and password.
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://apps.designcan.in/devs/vik/insurance/" target="_blank"><span>URL:</span> https://apps.designcan.in/devs/vik/insurance/</a>
                </div>
            </div>
            <h2 class="heading">Selfserve Widget</h2>
            <p class="para-description">
                Explore our self-serve options for convenient ticket management. View and track all your raised tickets, as well as create new ones as needed. Access a comprehensive FAQ section covering all aspects of your insurance
                policies for quick answers to your queries.
            </p>
            <div class="parent-div">
                <div class="child-div-half">
                    <a href="https://apps.designcan.in/devs/vik/insurance/" target="_blank"><span>URL:</span> https://apps.designcan.in/devs/vik/insurance/</a>
                </div>
                <div class="child-div-half">
                        <span>How to access:</span>
                        <div class="self-serve-btn"> 
                            <p>You can access the self serve widget by clicking on the button on the bottom right hand side.</p>
                            <button class="need-help-btn">Need help?</button>
                        </div>
                </div>
            </div>
            <h2 class="heading">Selfserve Portal</h2>
            <p class="para-description">
                This portal provides easy access to all integrated FAQs, allowing you to quickly find answers to common queries. You can browse through the FAQs to see what information has been added or updated. The system is designed to
                make it convenient for you to stay informed and resolve any doubts you may have.
            </p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://faq-demoinsurance.kapturecrm.com/" target="_blank"><span>URL:</span> https://faq-demoinsurance.kapturecrm.com/</a>
                </div>
            </div>
            <h2 class="heading">Selfserve Mobile Apps</h2>
            <p class="para-description">
                Access our self-serve features on our mobile apps, available for both Android and iOS platforms. Manage your account, raise tickets, and access FAQs conveniently on the go. Download our app now to experience seamless
                insurance management at your fingertips
            </p>
            <div class="parent-div">
                <div class="child-div-half">
                    <a href="https://faq-demoinsurance.kapturecrm.com/" target="_blank"><span> Google PlayStore URL:</span></a>
                </div>
                <div class="child-div-half">
                    <a href="https://faq-demoinsurance.kapturecrm.com/" target="_blank"><span> Apple AppStore URL:</span> </a>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion4" />
        <label for="accordion4" class="accordion-item-title"><span class="icon"></span>Social Media Integrations</label>
        <div class="accordion-item-desc">
            <p class="para-description">
                Seamlessly connect with Kapture CX through WhatsApp, Facebook, email, and other platforms. Raise tickets, share feedback, and interact with us effortlessly. Enhance your customer experience with our integrated social media
                functionalities
            </p>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/email.png" />
                    <p>bsfikapture@gmail.com</p>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/call.png" />
                    <p>08044634387</p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/whatsapp.png" />
                    <p>9606945374</p>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/twitter.png" />
                    <p></p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/Vector.png" />
                    <p></p>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/socialfb.png" />
                    <p></p>
                </div>
            </div>
            <div class="parent-div">
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/youtube.png" />
                    <p></p>
                </div>
                <div class="child-div-half-social">
                    <img src="<?php echo BASE_URL ?>/assets/img/instagram.png" />
                    <p></p>
                </div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion5" />
        <label for="accordion5" class="accordion-item-title"><span class="icon"></span>Gen AI</label>
        <div class="accordion-item-desc">
            <h2 class="heading">Gen AI KB</h2>
            <p class="para-description">
                The Gen AI Knowledge Base offers a variety of options for integration with the Gen AI chatbot on insurance website. Choose a module from the knowledge base to integrate with the chatbot, enhancing its capabilities.This
                integration allows the chatbot to provide more accurate and personalized responses to customer inquiries.
            </p>
            <p class="para-description">Please follow the steps below to access the Gen AI KB</p>
            <p class="note">Note:</p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="" target="_blank"><span>URL:</span> </a>
                </div>
            </div>
            <h2 class="heading">Create KB Link</h2>
            <p class="para-description">Please follow the steps below to access the Gen AI KB</p>
            <p class="note">Note:</p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="" target="_blank"><span>URL:</span> </a>
                </div>
            </div>
            <h2 class="heading">Select KB/Test it Out Option</h2>
            <p class="para-description">
                Choose the 'Select KB' option to pick a module that will be reflected in the website's AI chat. This feature allows you to customize the knowledge base content that the chatbot will use to respond to inquiries. Selecting the
                right module ensures that the chatbot provides accurate and relevant information to users.
            </p>
            <p class="method">Method 1</p>
            <p class="para-description">Please follow the steps below to select KB:</p>
            <p class="note">Note:</p>
            <p class="method">Method 2</p>
            <p class="para-description">Please follow the steps below to select KB:</p>
            <p></p>
            <p class="note">Note:</p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="" target="_blank"><span>URL:</span> </a>
                </div>
            </div>
            <h2 class="heading">Chat Link (in Insure Wise Link)</h2>
            <p class="para-description">
                Access our self-serve features on our mobile apps, available for both Android and iOS platforms. Manage your account, raise tickets, and access FAQs conveniently on the go. Download our app now to experience seamless
                insurance management at your fingertips
            </p>
            <div class="parent-div">
                <div class="child-div-half">
                    <a href="" target="_blank"><span>URL:</span> </a>
                </div>
                <div class="child-div-half"><span>URL:</span></div>
            </div>
        </div>
    </div>
    <div class="accordion-item">
        <input type="checkbox" id="accordion6" />
        <label for="accordion6" class="accordion-item-title"><span class="icon"></span>Sales Flow Documentation</label>
        <div class="accordion-item-desc">
            <p class="para-description">
                In this Sales Flow document, you'll find comprehensive information about our team members, account details, current queues, and folders. Explore the document to understand the structure and organization of our demo insurance
                account. If you have any questions or need further clarification, this document serves as a valuable resource to help you navigate the demo account efficiently.
            </p>
            <div class="parent-div">
                <div class="child-div-one">
                    <a href="https://docs.google.com/document/d/1me6ZxIsYLbVM5sHnaIBRCPSKINmphj_YSA56MIQpHmw/edit" target="_blank">
                        <span>URL:</span> &nbsp; https://docs.google.com/document/d/1me6ZxIsYLbVM5sHnaIBRCPSKINmphj_YSA56MIQpHmw/edit
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "../includes/footer.php"; ?>
