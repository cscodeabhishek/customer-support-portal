 <div style="display: flex;
    flex-direction: column;">
        <img src="<?php echo BASE_URL ?>/assets/img/footerimgg.png">
        <p style="background-color: #2A3342;margin: 0; padding: 0px 10px 10px 10px; text-align: center; color: #fff;">© 2024 Kapture CX. All rights reserved.</p>
    </div>
<script src="<?php echo BASE_URL ?>/assets/js/script.js"></script>
</body>
</html>